package com.ilkelimeturu.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import com.google.android.libraries.ads.mobile.sdk.common.AdRequest
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError
import com.google.android.libraries.ads.mobile.sdk.rewarded.RewardedAd
import com.google.android.libraries.ads.mobile.sdk.rewarded.RewardedAdEventCallback
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAd
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdEventCallback
import org.json.JSONArray

// Oyundaki titreşim isteklerini telefonun titreşim motoruna iletir.
class NativeBridge(private val activity: MainActivity) {
    private val vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    @JavascriptInterface
    fun vibrate(pattern: String) {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        try {
            val p = pattern.trim()
            if (p.startsWith("[")) {
                val a = JSONArray(p)
                val t = LongArray(a.length() + 1)
                for (i in 0 until a.length()) t[i + 1] = a.getLong(i)
                v.vibrate(VibrationEffect.createWaveform(t, -1))
            } else {
                val ms = p.toLong().coerceIn(1L, 500L)
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Exception) { }
    }

    // Called by the game's JavaScript showAd('rewarded'|'interstitial') function.
    @JavascriptInterface
    fun showAd(kind: String) {
        activity.runOnUiThread {
            if (kind == "rewarded") activity.showRewardedAd()
            else if (kind == "interstitial") activity.showInterstitialAd()
            else activity.finishAdRequest(false)
        }
    }
}

class MainActivity : Activity() {
    private var gameWebView: WebView? = null
    private var rewardedAd: RewardedAd? = null
    private var interstitialAd: InterstitialAd? = null
    private var adsInitialized = false

    companion object {
        private const val TAG = "KelimeTuruAds"
        // Google's official demo IDs. These show test ads only and earn no revenue.
        private const val ADMOB_APP_ID = "ca-app-pub-3940256099942544~3347511713"
        private const val REWARDED_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
        private const val INTERSTITIAL_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val web = WebView(this)
        gameWebView = web
        web.setBackgroundColor(Color.parseColor("#2B2150"))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.setSupportZoom(false)
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(NativeBridge(this), "KelimeNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        setContentView(web)

        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        initializeAds()
    }

    private fun initializeAds() {
        if (adsInitialized) return
        adsInitialized = true
        // SDK initialization is done off the UI thread as recommended by Google.
        Thread {
            try {
                MobileAds.initialize(
                    this,
                    InitializationConfig.Builder(ADMOB_APP_ID).build()
                ) {
                    runOnUiThread {
                        loadRewardedAd()
                        loadInterstitialAd()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Ad SDK initialization failed", e)
            }
        }.start()
    }

    private fun loadRewardedAd() {
        RewardedAd.load(
            AdRequest.Builder(REWARDED_UNIT_ID).build(),
            object : AdLoadCallback<RewardedAd> {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    Log.d(TAG, "Rewarded ad ready")
                }
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    rewardedAd = null
                    Log.w(TAG, "Rewarded ad load failed: ${adError.message}")
                }
            }
        )
    }

    private fun loadInterstitialAd() {
        InterstitialAd.load(
            AdRequest.Builder(INTERSTITIAL_UNIT_ID).build(),
            object : AdLoadCallback<InterstitialAd> {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    Log.d(TAG, "Interstitial ad ready")
                }
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    interstitialAd = null
                    Log.w(TAG, "Interstitial ad load failed: ${adError.message}")
                }
            }
        )
    }

    fun showRewardedAd() {
        val ad = rewardedAd
        if (ad == null) {
            finishAdRequest(false)
            loadRewardedAd()
            return
        }
        rewardedAd = null
        var earned = false
        ad.adEventCallback = object : RewardedAdEventCallback {
            override fun onAdDismissedFullScreenContent() {
                finishAdRequest(earned)
                loadRewardedAd()
            }
            override fun onAdFailedToShowFullScreenContent(fullScreenContentError: com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError) {
                Log.w(TAG, "Rewarded ad show failed: ${fullScreenContentError.message}")
                finishAdRequest(false)
                loadRewardedAd()
            }
        }
        ad.show(this) {
            earned = true
        }
    }

    fun showInterstitialAd() {
        val ad = interstitialAd
        if (ad == null) {
            finishAdRequest(false)
            loadInterstitialAd()
            return
        }
        interstitialAd = null
        ad.adEventCallback = object : InterstitialAdEventCallback {
            override fun onAdDismissedFullScreenContent() {
                finishAdRequest(true)
                loadInterstitialAd()
            }
            override fun onAdFailedToShowFullScreenContent(fullScreenContentError: com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError) {
                Log.w(TAG, "Interstitial show failed: ${fullScreenContentError.message}")
                finishAdRequest(false)
                loadInterstitialAd()
            }
        }
        ad.show(this)
    }

    fun finishAdRequest(success: Boolean) {
        val value = if (success) "true" else "false"
        gameWebView?.post {
            gameWebView?.evaluateJavascript(
                "if (window.__adDone) { const cb = window.__adDone; window.__adDone = null; cb($value); }",
                null
            )
        }
    }

    override fun onDestroy() {
        gameWebView?.removeJavascriptInterface("KelimeNative")
        gameWebView?.destroy()
        gameWebView = null
        super.onDestroy()
    }
}
