# AdMob kurulumu

Bu sürüm Google AdMob ile gelir: ödüllü reklam ("Reklam izle"), geçiş reklamı (reklamsız değilken her 2 seviyede bir) ve AB/UK için onay formu (UMP).

## Şu an (test)
Debug derleme her zaman Google'ın TEST reklam kimliklerini kullanır. GitHub'daki derleme debug olduğu için telefonda "Test Ad" yazan reklamlar görürsün. Test reklamlara tıklamak güvenlidir.
**Geliştirirken kendi gerçek reklamlarına asla tıklama**, hesabın kapatılabilir.

## Gerçek reklamlara geçiş
1. admob.google.com'da hesap aç, uygulamanı ekle (önce Play'e yüklemen gerekebilir; yayından önce de ekleyebilirsin).
2. Bir "Ödüllü" ve bir "Geçiş" reklam birimi oluştur.
3. `gradle.properties` dosyasına yaz (ya da `-P` ile ver):
   ```
   ADMOB_APP_ID=ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY
   ADMOB_REWARDED_ID=ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ
   ADMOB_INTERSTITIAL_ID=ca-app-pub-XXXXXXXXXXXXXXXX/WWWWWWWWWW
   ```
4. `gradle bundleRelease` ile imzalı AAB üret. Kimlikler yoksa release de test kimliğiyle derlenir (güvenli ama kazanç olmaz).
5. AdMob > Gizlilik ve mesajlaşma bölümünde AB onay mesajını (UMP) oluşturup yayınla.
6. Play Console'da: Veri güvenliği formunda reklam kimliği ve reklam kullanımını bildir; "Reklam Kimliği" beyanını yap.

## Davranış
- Ödüllü reklam bitmeden kapatılırsa ödül verilmez.
- Reklam hazır değilse oyun "Reklam şu an hazır değil" der. Geçiş reklamı hazır değilse oyun beklemeden devam eder.
- Reklamsız süre ya da abonelik aktifken geçiş reklamı gösterilmez; ödüllü reklam isteğe bağlıdır.
- Gizlilik seçeneği gereken bölgelerde Ayarlar'da "Reklam gizliliği seçenekleri" düğmesi görünür.
