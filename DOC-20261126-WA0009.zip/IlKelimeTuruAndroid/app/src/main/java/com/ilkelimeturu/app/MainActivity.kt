package com.ilkelimeturu.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray

// Oyundaki titreşim isteklerini telefonun titreşim motoruna iletir (window.KelimeNative.vibrate).
class NativeBridge(private val activity: Activity, private val ads: Ads) {
    private val vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    // Reklam istekleri: oyundan (JS iş parçacığı) ana iş parçacığına aktarılır
    @JavascriptInterface
    fun showAd(kind: String) { activity.runOnUiThread { ads.show(kind) } }

    @JavascriptInterface
    fun privacyRequired(): Boolean = ads.privacyOptionsRequired

    @JavascriptInterface
    fun showPrivacy() { activity.runOnUiThread { ads.showPrivacyOptions() } }

    @JavascriptInterface
    fun vibrate(pattern: String) {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        try {
            val p = pattern.trim()
            if (p.startsWith("[")) {
                // [titre, bekle, titre, ...] biçimi; Android için başa 0 ms bekleme ekliyoruz
                val a = JSONArray(p)
                val t = LongArray(a.length() + 1)
                for (i in 0 until a.length()) t[i + 1] = a.getLong(i)
                v.vibrate(VibrationEffect.createWaveform(t, -1))
            } else {
                val ms = p.toLong().coerceIn(1L, 500L)
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (e: Exception) {
            // titreşim başarısız olursa oyun etkilenmesin
        }
    }
}

class MainActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Oyun dosyalarını (assets) güvenli bir https adresi gibi sunar; localStorage kalıcı olur.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#2B2150"))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.setSupportZoom(false)
        web.settings.mediaPlaybackRequiresUserGesture = false // ses efektleri için
        val ads = Ads(this, web)
        web.addJavascriptInterface(NativeBridge(this, ads), "KelimeNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        setContentView(web)

        // Durum ve gezinme çubuklarının altında kalmasın
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        ads.start()
    }
}
