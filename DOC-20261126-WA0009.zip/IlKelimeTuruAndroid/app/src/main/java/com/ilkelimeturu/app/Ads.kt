package com.ilkelimeturu.app

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * Google AdMob: onay formu (UMP), ödüllü reklam ve geçiş (interstitial) reklamı.
 * Tüm işlevler ana iş parçacığında çağrılmalıdır. Sonuç oyuna window.__adDone(ok, neden) ile döner.
 * Reklam kimlikleri BuildConfig'ten gelir: debug her zaman Google'ın TEST kimliklerini kullanır.
 */
class Ads(private val activity: Activity, private val web: WebView) {
    private val main = Handler(Looper.getMainLooper())
    private val consent: ConsentInformation = UserMessagingPlatform.getConsentInformation(activity)

    private var sdkStarted = false
    private var rewarded: RewardedAd? = null
    private var rewardedAt = 0L
    private var loadingRewarded = false
    private var interstitial: InterstitialAd? = null
    private var interstitialAt = 0L
    private var loadingInterstitial = false
    private var showing = false

    /** Ayarlarda "Reklam gizliliği seçenekleri" düğmesi gösterilsin mi (JS buradan okur). */
    @Volatile var privacyOptionsRequired = false
        private set

    /** Uygulama açılışında bir kez çağır: önce onay bilgisi, uygunsa SDK başlatılır. */
    fun start() {
        val params = ConsentRequestParameters.Builder().build()
        consent.requestConsentInfoUpdate(
            activity, params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ -> afterConsent() }
            },
            { _ -> afterConsent() }
        )
        // Önceki oturumdan onay zaten varsa beklemeden başla
        afterConsent()
    }

    private fun afterConsent() {
        privacyOptionsRequired =
            consent.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
        if (sdkStarted || !consent.canRequestAds()) return
        sdkStarted = true
        Thread {
            MobileAds.initialize(activity) { main.post { loadRewarded(); loadInterstitial() } }
        }.start()
    }

    fun showPrivacyOptions() {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ -> afterConsent() }
    }

    private fun fresh(at: Long) = System.currentTimeMillis() - at < 55 * 60 * 1000 // reklamlar 1 saatte geçersiz olur

    private fun loadRewarded() {
        if (!sdkStarted || loadingRewarded || (rewarded != null && fresh(rewardedAt)) || activity.isFinishing) return
        loadingRewarded = true
        RewardedAd.load(activity, BuildConfig.ADMOB_REWARDED, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewarded = ad; rewardedAt = System.currentTimeMillis(); loadingRewarded = false
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewarded = null; loadingRewarded = false
                    main.postDelayed({ loadRewarded() }, 30_000)
                }
            })
    }

    private fun loadInterstitial() {
        if (!sdkStarted || loadingInterstitial || (interstitial != null && fresh(interstitialAt)) || activity.isFinishing) return
        loadingInterstitial = true
        InterstitialAd.load(activity, BuildConfig.ADMOB_INTERSTITIAL, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad; interstitialAt = System.currentTimeMillis(); loadingInterstitial = false
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null; loadingInterstitial = false
                    main.postDelayed({ loadInterstitial() }, 30_000)
                }
            })
    }

    /** kind: "rewarded" ya da "interstitial". Her çağrıya mutlaka tek bir __adDone yanıtı verilir. */
    fun show(kind: String) {
        if (showing) { done(false, "busy"); return }
        if (kind == "rewarded") showRewarded() else showInterstitial()
    }

    private fun showRewarded() {
        val ad = rewarded
        if (ad == null || !fresh(rewardedAt)) {
            rewarded = null; loadRewarded(); done(false, "notready"); return
        }
        rewarded = null
        showing = true
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { showing = false; loadRewarded(); done(earned, "") }
            override fun onAdFailedToShowFullScreenContent(error: AdError) { showing = false; loadRewarded(); done(false, "notready") }
        }
        ad.show(activity, OnUserEarnedRewardListener { earned = true })
    }

    private fun showInterstitial() {
        val ad = interstitial
        // Reklam hazır değilse oyunu bekletme: devam etmesine izin ver
        if (ad == null || !fresh(interstitialAt)) {
            interstitial = null; loadInterstitial(); done(true, "notready"); return
        }
        interstitial = null
        showing = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { showing = false; loadInterstitial(); done(true, "") }
            override fun onAdFailedToShowFullScreenContent(error: AdError) { showing = false; loadInterstitial(); done(true, "") }
        }
        ad.show(activity)
    }

    private fun done(ok: Boolean, why: String) {
        web.post { web.evaluateJavascript("window.__adDone&&window.__adDone($ok,'$why')", null) }
    }
}
