plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Google'ın herkese açık TEST reklam kimlikleri (tıklamak güvenlidir)
val testAppId = "ca-app-pub-3940256099942544~3347511713"
val testRewarded = "ca-app-pub-3940256099942544/5224354917"
val testInterstitial = "ca-app-pub-3940256099942544/1033173712"
// Release için gerçek kimlikler gradle.properties ya da -P ile verilir; verilmezse test kimlikleri kullanılır
fun adProp(name: String, fallback: String): String =
    (project.findProperty(name) as String?)?.trim()?.takeIf { it.isNotEmpty() } ?: fallback

android {
    namespace = "com.ilkelimeturu.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ilkelimeturu.app" // Play'e yüklemeden önce kendi benzersiz adınla değiştir
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    buildFeatures { buildConfig = true }
    buildTypes {
        debug {
            // Geliştirirken asla gerçek reklam kimliği kullanma (hesap askıya alınabilir)
            manifestPlaceholders["admobAppId"] = testAppId
            buildConfigField("String", "ADMOB_REWARDED", "\"$testRewarded\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL", "\"$testInterstitial\"")
        }
        release {
            isMinifyEnabled = false
            manifestPlaceholders["admobAppId"] = adProp("ADMOB_APP_ID", testAppId)
            buildConfigField("String", "ADMOB_REWARDED", "\"" + adProp("ADMOB_REWARDED_ID", testRewarded) + "\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL", "\"" + adProp("ADMOB_INTERSTITIAL_ID", testInterstitial) + "\"")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.gms:play-services-ads:25.5.0")
    implementation("com.google.android.ump:user-messaging-platform:4.0.0")
}
