#!/usr/bin/env python3
"""
81 il için fotoğrafları Vikipedi + Wikimedia Commons'tan indirir.

- Yalnızca serbest lisanslı (CC0, kamu malı, CC BY, CC BY-SA) dosyalar alınır.
- Fotoğraflar küçültülüp app/src/main/assets/img/NN.jpg olarak kaydedilir (NN = plaka kodu).
- Fotoğrafçı ve lisans bilgisi assets/img/credits.json dosyasına yazılır; oyun bunu
  Ayarlar > Fotoğraf kaynakları bölümünde gösterir (CC BY / CC BY-SA için gereklidir).
- Hiçbir şey indirilemezse oyun çizimlerle çalışmaya devam eder; bu betik hiçbir zaman derlemeyi bozmaz.
- Elle koymak istediğin fotoğraf: assets/img/NN.jpg dosyasını depoya ekle; betik o ili atlar.
  Kaynak bilgisini tools/credits_manual.json içine {"NN": {"author": "...", "license": "..."}} ekle.
"""
import html, io, json, os, re, sys, time, urllib.parse, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PLACES = ROOT / "tools" / "places.json"
MANUAL = ROOT / "tools" / "credits_manual.json"
OUT = ROOT / "app" / "src" / "main" / "assets" / "img"
UA = "81IlKelimeTuru/1.0 (https://github.com/%s; oyun derleme betigi)" % os.environ.get("GITHUB_REPOSITORY", "yerel")

LICENSE_OK = re.compile(r"^(CC0.*|CC BY(-SA)? \d(\.\d)?( [A-Za-z]+)?|Public domain.*|PD[- ].*|Attribution.*)$", re.I)
LICENSE_BAD = re.compile(r"(\bNC\b|-NC|\bND\b|-ND|fair use|GFDL|non-?free)", re.I)
MIN_W, MIN_H = 600, 450
MAX_SIDE = 1000
RATIO = (0.55, 2.2)  # en/boy sınırları; çok uzun panoramalar elenir


def api(host, params):
    q = urllib.parse.urlencode({**params, "format": "json", "formatversion": "2"})
    req = urllib.request.Request("https://%s/w/api.php?%s" % (host, q), headers={"User-Agent": UA})
    last = None
    for i in range(3):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.load(r)
        except Exception as e:  # ağ hatasında tekrar dene
            last = e
            time.sleep(1.5 * (i + 1))
    raise last


def download(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    last = None
    for i in range(3):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.read()
        except Exception as e:
            last = e
            time.sleep(2 * (i + 1))
    raise last


def lead_image(wiki, title):
    d = api("%s.wikipedia.org" % wiki, {"action": "query", "titles": title, "prop": "pageimages",
                                         "piprop": "name", "redirects": 1})
    pages = d.get("query", {}).get("pages", [])
    return pages[0].get("pageimage") if pages and not pages[0].get("missing") else None


def clean(s):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", "", s or ""))).strip()


def commons_info(filename):
    d = api("commons.wikimedia.org", {"action": "query", "titles": "File:" + filename, "prop": "imageinfo",
                                       "iiprop": "url|extmetadata|size|mime", "iiurlwidth": MAX_SIDE})
    pages = d.get("query", {}).get("pages", [])
    if not pages or pages[0].get("missing") or not pages[0].get("imageinfo"):
        return None, "Commons'ta yok"
    ii = pages[0]["imageinfo"][0]
    meta = ii.get("extmetadata", {})
    lic = clean(meta.get("LicenseShortName", {}).get("value"))
    if not lic or LICENSE_BAD.search(lic) or not LICENSE_OK.match(lic):
        return None, "lisans uygun degil: %r" % lic
    if clean(meta.get("NonFree", {}).get("value")).lower() in ("1", "true", "yes"):
        return None, "ucretsiz degil"
    if ii.get("mime") not in ("image/jpeg", "image/png"):
        return None, "tur uygun degil: %s" % ii.get("mime")
    w, h = ii.get("width", 0), ii.get("height", 0)
    if w < MIN_W or h < MIN_H:
        return None, "kucuk: %sx%s" % (w, h)
    if not (RATIO[0] <= w / h <= RATIO[1]):
        return None, "oran uygun degil: %.2f" % (w / h)
    author = clean(meta.get("Artist", {}).get("value")) or clean(meta.get("Credit", {}).get("value")) or "Bilinmiyor"
    return {"url": ii.get("thumburl") or ii["url"], "page": ii.get("descriptionurl", ""),
            "license": lic, "author": author[:80]}, None


def save_jpeg(data, path):
    from PIL import Image
    im = Image.open(io.BytesIO(data)).convert("RGB")
    im.thumbnail((MAX_SIDE, MAX_SIDE))
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path, "JPEG", quality=78, optimize=True, progressive=True)


def run(places, out=OUT, manual=None, log=print):
    credits, report, used = {}, [], set()
    manual = manual or {}
    for p in places:
        nn = "%02d" % p["plaka"]
        target = out / (nn + ".jpg")
        if target.exists():
            credits[nn] = manual.get(nn) or {"author": "Elle eklendi", "license": "-"}
            credits[nn]["il"] = p["il"]
            report.append("%s %-15s ELLE EKLENEN FOTOGRAF" % (nn, p["il"]))
            continue
        if not p["kaynak"]:
            report.append("%s %-15s fotograf yok (cizim kullanilacak)" % (nn, p["il"]))
            continue
        why = []
        done = False
        for wiki, title in p["kaynak"]:
            try:
                fn = lead_image(wiki, title)
                if not fn:
                    why.append("%s:%s -> sayfa/gorsel yok" % (wiki, title))
                    continue
                if fn in used:
                    why.append("%s:%s -> baska ilde kullanildi" % (wiki, title))
                    continue
                info, err = commons_info(fn)
                if not info:
                    why.append("%s:%s (%s) -> %s" % (wiki, title, fn, err))
                    continue
                save_jpeg(download(info["url"]), target)
                used.add(fn)
                credits[nn] = {"il": p["il"], "file": fn, "author": info["author"], "license": info["license"], "page": info["page"]}
                report.append("%s %-15s TAMAM  %s | %s | %s" % (nn, p["il"], fn, info["license"], info["author"]))
                done = True
                break
            except Exception as e:
                why.append("%s:%s -> hata: %s" % (wiki, title, e))
        if not done:
            report.append("%s %-15s BULUNAMADI (cizim kullanilacak) :: %s" % (nn, p["il"], " ; ".join(why)))
        time.sleep(0.2)
    out.mkdir(parents=True, exist_ok=True)
    (out / "credits.json").write_text(json.dumps(credits, ensure_ascii=False, indent=1), encoding="utf-8")
    ok = sum(1 for r in report if " TAMAM " in r or "ELLE EKLENEN" in r)
    log("\n".join(report))
    log("\nOzet: %d/%d il icin fotograf var." % (ok, len(places)))
    return credits, report


def main():
    try:
        import PIL  # noqa: F401
    except ImportError:
        print("Pillow yok; fotograf indirme atlandi (oyun cizimlerle calisir).")
        return 0
    places = json.loads(PLACES.read_text(encoding="utf-8"))
    manual = json.loads(MANUAL.read_text(encoding="utf-8")) if MANUAL.exists() else {}
    try:
        run(places, OUT, manual)
    except Exception as e:  # hicbir durumda derlemeyi bozma
        print("Fotograf indirme hatasi (atlandi):", e)
    return 0


if __name__ == "__main__":
    sys.exit(main())
